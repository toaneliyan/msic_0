#!/bin/sh 
date;
jg setup_reqack_sol.tcl
 
