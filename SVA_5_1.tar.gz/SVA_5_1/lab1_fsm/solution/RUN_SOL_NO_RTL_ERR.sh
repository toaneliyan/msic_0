#!/bin/sh
jg fsm_if_w_props_no_rtl_errors.tcl
