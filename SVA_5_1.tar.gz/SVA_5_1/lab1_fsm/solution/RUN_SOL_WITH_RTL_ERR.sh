#!/bin/sh
jg fsm_if_w_props_rtl_errors.tcl
